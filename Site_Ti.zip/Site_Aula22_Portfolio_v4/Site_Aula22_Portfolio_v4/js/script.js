/* setTimeout(function(){
    window.onload = window.alert("Olá!!!\nBem-vindo ao meu Portfólio!!! Meu nome é ENZO");
},2000);  */


let msg_alerta = '<div class="alert-box">'
+'<h1><i class="bi bi-rocket-takeoff-fill"></i><h1>'
+'<h2>Bem-Vindo ao meu Portfólio!!!</h2>'
+'<h3>Meu nome é Enzo!</h3>'
+'<input class="btn btn-outline-info" type="button" value="OK" onclick="this.parentNode.outerHTML=\'\';window.location.close()" />'
+'</div>';

document.write(msg_alerta);

